setwd("C:/Users/Annabel Seah/Documents/UCL/Bayesian/Session 3")
library("BCEA")
library("R2OpenBUGS")
y <- 241945
n <- 493527
data <- list(y=y,n=n)
filein <- "C:/Users/Annabel Seah/Documents/UCL/Bayesian/Session 3/ModelLaplace.txt"
params <- "theta" #this is the variable you want to monitor
inits_det <- list(list(theta=.1),list(theta=.9)) #fixed theta values
inits_ran <- function(){list(theta=runif(1))} #random theta values
model <- bugs(data=data,inits=inits_ran,
              parameters.to.save=params,model.file=filein,
              n.chains=2,n.iter=10000,n.burnin=4500,
              n.thin=1,DIC=TRUE)
names(model)
model$n.iter
model
attach.bugs(model)
hist(theta)
plot(theta)
load("Vaccine.Rdata")
names(he)
he$delta.c
ce = mean(he$delta.c)/mean(he$delta.e)
ce

k = 30000
eib = k*mean(he$delta.e) - mean(he$delta.c)
eib
ceplane.plot(he,wtp=10000)
he$ICER=ce #add this to show the ICER in the ceplane plot
