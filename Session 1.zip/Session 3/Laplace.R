# 1. Loads the data
y <- 241945
n <- 493527
data <- list(y=y,n=n)

# 2. Defines the physical location of the model file, 
#    the parameters list and the inits (either using 
#    deterministic values, or randomly selected values)
filein <- "ModelLaplace.txt"
params <- "theta"
inits_det <- list(list(theta=.1),list(theta=.9))
inits_ran <- function(){list(theta=runif(1))}

# 3. Loads the package R2OpenBUGS to connect R to OpenBUGS & 
#    runs the MCMC 
library(R2OpenBUGS)
model <- bugs(data=data,inits=inits_det,
              parameters.to.save=params,model.file=filein,
              n.chains=2,n.iter=10000,n.burnin=4500,n.thin=1,
              DIC=TRUE)

# 4. Explores the object "model"
names(model)

# 5. Prints the summary results
print(model,digits=3,interval=c(.025,.975))

# 6. Makes the elements of the object "model" available to 
#    the R session
attach.bugs(model)

# 7. And then uses them
hist(theta)
